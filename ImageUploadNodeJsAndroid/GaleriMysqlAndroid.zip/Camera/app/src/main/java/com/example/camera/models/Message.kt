package com.example.camera.models

data class Message(
    var msg: String?
)
