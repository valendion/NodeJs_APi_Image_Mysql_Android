package com.example.retrofitcoroutine.data.network

import com.example.camera.models.Message
import com.example.camera.models.ResponseImage
import retrofit2.http.*

interface ApiService {

    @GET("getAll")
    suspend fun images(): List<ResponseImage>

    @FormUrlEncoded
    @POST("post_image")
    suspend fun postImage(@Field("name_image",)name_image: String, @Field("path")path: String): Message
}