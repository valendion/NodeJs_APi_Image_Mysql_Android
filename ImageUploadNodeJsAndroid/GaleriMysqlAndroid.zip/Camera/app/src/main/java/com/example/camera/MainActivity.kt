package com.example.camera


import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Base64
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import com.example.camera.databinding.ActivityMainBinding
import com.example.retrofitcoroutine.data.network.ApiConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.lang.Exception


class MainActivity : AppCompatActivity() {
    var bitmap: Bitmap? = null
    var decoded: Bitmap? = null
    var success = 0
    var PICK_IMAGE_REQUEST = 1
    var bitmap_size = 60 // range 1 - 100
    var name: String? = null
    var imageUpload: String? = null

    lateinit var binding: ActivityMainBinding

    //    private val TAG = MainActivity::class.java.simpleName
    private val TAG = "Gambar"


    var tag_json_obj = "json_obj_req"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.apply {
            imageCamera.setOnClickListener {
                showFileChooser()
            }

            btnSave.setOnClickListener {
                name = inputName.text.toString()
                imageUpload = getStringImage(decoded!!)
                uploadImage()
                startActivity(Intent(this@MainActivity, ItemImageActivity::class.java))

            }
        }

    }


    fun getStringImage(bmp: Bitmap): String {
        val baos = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, bitmap_size, baos)
        val imageBytes: ByteArray = baos.toByteArray()
        return Base64.encodeToString(imageBytes, Base64.DEFAULT)
    }

    private fun uploadImage() {
        //menampilkan progress dialog
        CoroutineScope(Dispatchers.IO).launch {
            try {

                val message = ApiConfig.instance.postImage(name!!, imageUpload!!)

                CoroutineScope(Dispatchers.Main).launch {
                    message.msg?.let { Log.e(TAG, it) }
                    Log.e(TAG, imageUpload!!)
                    Toast.makeText(applicationContext, message.msg, Toast.LENGTH_SHORT).show()
                }


            } catch (error: Exception) {
                Log.e(TAG, error.toString())
            }


        }
    }

    private fun showFileChooser() {
        val intent = Intent()
        intent.type = "image/*"
        intent.action = Intent.ACTION_GET_CONTENT
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.data != null) {
            val filePath: Uri? = data.data
            try {
                //mengambil fambar dari Gallery
                bitmap = MediaStore.Images.Media.getBitmap(contentResolver, filePath)
                // 512 adalah resolusi tertinggi setelah image di resize, bisa di ganti.
                setToImageView(getResizedBitmap(bitmap!!, 512))
            } catch (e: IOException) {
                e.printStackTrace()
            }
        }
    }

    private fun kosong() {
        binding.apply {
            imageCamera.setImageResource(0)
            inputName.setText(null)
        }
    }

    private fun setToImageView(bmp: Bitmap) {
        //compress image
        val bytes = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, bitmap_size, bytes)
        decoded = BitmapFactory.decodeStream(ByteArrayInputStream(bytes.toByteArray()))

        //menampilkan gambar yang dipilih dari camera/gallery ke ImageView
        binding.imageCamera.setImageBitmap(decoded)
    }

    // fungsi resize image
    fun getResizedBitmap(image: Bitmap, maxSize: Int): Bitmap {
        var width = image.width
        var height = image.height
        val bitmapRatio = width.toFloat() / height.toFloat()
        if (bitmapRatio > 1) {
            width = maxSize
            height = (width / bitmapRatio).toInt()
        } else {
            height = maxSize
            width = (height * bitmapRatio).toInt()
        }
        return Bitmap.createScaledBitmap(image, width, height, true)
    }
}