package com.example.camera

import android.graphics.Bitmap
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.camera.databinding.ListItemImageBinding
import com.example.camera.models.ResponseImage
import android.graphics.BitmapFactory
import android.util.Base64


class AdapterMain() :
    RecyclerView.Adapter<AdapterMain.MainHolder>() {

    private var data = listOf<ResponseImage>()

    fun set(data: List<ResponseImage>) {
        this.data = data
        notifyDataSetChanged()
    }

    inner class MainHolder(val binding: ListItemImageBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(user: ResponseImage) {



            binding.apply {
                textName.text = user.nameImage
                Glide.with(binding.root)
                    .load(user.path?.let { ToBitmap(it) })
                    .into(imageData)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MainHolder {
        return MainHolder(
            ListItemImageBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )
    }

    override fun onBindViewHolder(holder: MainHolder, position: Int) {
        holder.bind(data[position])
    }

    fun ToBitmap(path: String): Bitmap{
        var decodedString: ByteArray = Base64.decode(path, Base64.DEFAULT)
        return  BitmapFactory.decodeByteArray(decodedString, 0, decodedString.size)
    }

    override fun getItemCount(): Int = data.size

}