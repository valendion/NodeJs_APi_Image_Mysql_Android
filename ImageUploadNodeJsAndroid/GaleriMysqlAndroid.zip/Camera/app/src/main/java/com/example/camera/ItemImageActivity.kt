package com.example.camera

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.LinearLayout
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.camera.databinding.ActivityItemImageBinding
import com.example.camera.databinding.ActivityMainBinding
import com.example.retrofitcoroutine.data.network.ApiConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ItemImageActivity : AppCompatActivity() {
    lateinit var binding: ActivityItemImageBinding
    private lateinit var adapter: AdapterMain
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityItemImageBinding.inflate(layoutInflater)
        setContentView(binding.root)

        initRecyclerView()
        initView()
    }

    private fun initView(){
        CoroutineScope(Dispatchers.IO).launch {
            val listener = ApiConfig.instance.images()

            CoroutineScope(Dispatchers.Main).launch{
                adapter.set(listener)
            }
        }
    }

    private fun initRecyclerView() {
        binding.rvImage.layoutManager = LinearLayoutManager(this)
        adapter = AdapterMain()
        binding.rvImage.adapter = adapter
    }



}