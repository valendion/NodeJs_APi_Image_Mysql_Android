const  Sequelize  = require('sequelize')
const db = require('../config/db')

const Image = db.define(
    'image',
    {
        name_image: {type: Sequelize.TEXT},
        path: {type: Sequelize.TEXT}
    },
    {
        freezeTableName: true
    }
)

module.exports = Image