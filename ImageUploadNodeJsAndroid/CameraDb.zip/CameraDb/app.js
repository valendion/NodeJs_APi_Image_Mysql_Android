const express = require('express')
const app = express()

const db = require('./config/db')

const Image = require('./models/Image')

app.get('/', (req, res) =>{
    res.send('Respon nodejs berhasil')
})

app.use(express.urlencoded({extended: true}))

db.authenticate().then(() => console.log('Berhasil terkoneksi dengan database'))

app.post('/post_image', async (req, res) => {
    try{
        const {name_image, path} = req.body;

        const newImage = new Image({
            name_image,
            path
        })

        await newImage.save()

        res.send({
            msg: 'Data tersimpan'
        })
    }
    catch(err){
        console.error(err.message)
        res.status(400).send({
            msg: 'Data gagal tersimpan'
        })
    }
})

app.get('/getAll', async (req, res) =>{
    try {
        const getAllImage = await Image.findAll({})

        res.json(getAllImage)
    } catch (error) {
        console.error(error.message)
        res.status(400).send({
            msg: 'Data gagal tersimpan'
        })
    }
})

app.listen(3000, () =>{
    console.log('Port berjalan 3000')
})