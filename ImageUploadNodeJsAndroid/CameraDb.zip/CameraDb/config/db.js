const sequelize = require('sequelize')

const db = new sequelize('image_camera','root','', {
    dialect: 'mysql'
})

db.sync({})

module.exports = db